Run this example using secrets

`habitus --build host=[ip of habitus endpoint] --host=unix:///var/run/docker.sock --binding=0.0.0.0 --secrets=true`